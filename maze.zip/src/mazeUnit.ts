class mazeUnit extends egret.HashObject{

    public view:egret.DisplayObject;
    public x:number = -1;
    public y:number = -1;
    public top:number = 1;
    public right:number = 1;
    public bottom:number = 1;
    public left:number = 1;

    constructor() {
        super();
    }

}