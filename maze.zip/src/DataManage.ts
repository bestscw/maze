class DataManage {

    public static maze:Array<any> = [];
    public static maze2:Array<any> = [];

    public static  M:number = 8; //宫数
    public static  S:number = 60; // 迷宫格大小
    public static  _postArr:Array<any> = [[0, -1],[1, 0],[0, 1],[-1, 0]];
    public static mazeOrder:Array<any> = [];
    public static mazeUnit2:Array<any> = [1, 1, 1, 1 ];

    public static getMazeUnitByPos(x:number,y:number)
    {
        for(var i:number=0; i<DataManage.maze.length; i++)
        {
            if(DataManage.maze[i].x == x &&  DataManage.maze[i].y == y)
            {
                return DataManage.maze[i];
            }
        }

        return null;
    }

    public static getMaze2UnitByPos(x:number,y:number)
    {
        for(var i:number=0; i<DataManage.maze2.length; i++)
        {
            if(DataManage.maze2[i].x == x &&  DataManage.maze2[i].y == y)
            {
                return DataManage.maze2[i];
            }
        }

        return null;
    }

    public static removeMazeUnitByPos(x:number,y:number)
    {

        for(var m:number=0; m<DataManage.maze.length; m++)
        {
            if(DataManage.maze[m].x == x &&  DataManage.maze[m].y == y)
            {
                DataManage.maze.splice(m,1);
            }
        }

        return true;
    }
}