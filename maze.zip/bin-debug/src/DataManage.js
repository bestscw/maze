var DataManage = (function () {
    function DataManage() {
    }
    DataManage.getMazeUnitByPos = function (x, y) {
        for (var i = 0; i < DataManage.maze.length; i++) {
            if (DataManage.maze[i].x == x && DataManage.maze[i].y == y) {
                return DataManage.maze[i];
            }
        }
        return null;
    };
    DataManage.getMaze2UnitByPos = function (x, y) {
        for (var i = 0; i < DataManage.maze2.length; i++) {
            if (DataManage.maze2[i].x == x && DataManage.maze2[i].y == y) {
                return DataManage.maze2[i];
            }
        }
        return null;
    };
    DataManage.removeMazeUnitByPos = function (x, y) {
        for (var m = 0; m < DataManage.maze.length; m++) {
            if (DataManage.maze[m].x == x && DataManage.maze[m].y == y) {
                DataManage.maze.splice(m, 1);
            }
        }
        return true;
    };
    DataManage.maze = [];
    DataManage.maze2 = [];
    DataManage.M = 8; //宫数
    DataManage.S = 60; // 迷宫格大小
    DataManage._postArr = [[0, -1], [1, 0], [0, 1], [-1, 0]];
    DataManage.mazeOrder = [];
    DataManage.mazeUnit2 = [1, 1, 1, 1];
    return DataManage;
})();
